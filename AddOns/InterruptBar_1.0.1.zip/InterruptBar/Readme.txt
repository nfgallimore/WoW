Adding Spells:
1. Click "InterruptBar.lua" then choose to open it with Notepad, or any other text editors.
2. Read what it says at the top of the file you just opened. It will explain the rest.

Adding Textures:
1. Download the textures you want to use. I have only tested it myself with: http://www.curse.com/addons/wow/masque_darion so I can't guarantee that other textures will work 100%
2. Create a folder called media inside Interface/AddOns/Interruptbar/
3. Place "Backdrop.tga", "Gloss.tga" and "Normal.tga" inside the media folder.
4. Restart World of Warcraft then type "/ib border" ingame to load the textures.


