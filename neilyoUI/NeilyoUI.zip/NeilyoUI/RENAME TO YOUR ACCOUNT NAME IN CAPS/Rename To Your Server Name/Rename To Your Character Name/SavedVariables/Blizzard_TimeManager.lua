
BlizzardStopwatchOptions = {
	["position"] = {
		["y"] = 587.1747550420373,
		["x"] = 522.7697231363127,
	},
}
