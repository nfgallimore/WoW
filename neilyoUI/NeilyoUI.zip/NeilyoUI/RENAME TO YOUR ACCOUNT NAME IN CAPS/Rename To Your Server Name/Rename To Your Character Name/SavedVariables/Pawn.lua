
PawnOptions = {
	["LastPlayerFullName"] = "Neilyoirl-Tichondrius",
	["LastKeybindingsSet"] = 1,
}
PawnWowheadScaleProviderOptions = {
	["LastClass"] = "ROGUE",
	["LastAdded"] = 2,
}
