
BattlefieldMinimapOptions = {
	["locked"] = true,
	["opacity"] = 0,
	["showPlayers"] = true,
	["position"] = {
		["y"] = 369.66630596957,
		["x"] = 1527.889260269592,
	},
}
