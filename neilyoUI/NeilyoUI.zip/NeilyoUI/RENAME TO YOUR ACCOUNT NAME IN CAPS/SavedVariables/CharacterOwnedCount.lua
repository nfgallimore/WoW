
CHAR_OWNED = {
	["Tichondrius.Neilyoirl"] = 0,
	["config"] = {
		["enablesound"] = true,
		["duration"] = 4,
	},
}
