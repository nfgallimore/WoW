
OneRing_Config = {
	["ProfileStorage"] = {
		["default"] = {
		},
	},
	["PersistentStorage"] = {
	},
	["CharProfiles"] = {
	},
}
