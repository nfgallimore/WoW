
caelDB = {
	["scale"] = 0.85,
}
