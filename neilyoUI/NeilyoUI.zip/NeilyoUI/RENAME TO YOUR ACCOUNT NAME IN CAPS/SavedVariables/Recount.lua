
RecountDB = {
	["profileKeys"] = {
		["Neilyoh - Kel'Thuzad"] = "Neilyoh - Kel'Thuzad",
		["Neilyoirl - Tichondrius"] = "Neilyoirl - Tichondrius",
		["Neilyoingame - Kel'Thuzad"] = "Neilyoingame - Kel'Thuzad",
	},
	["profiles"] = {
		["Neilyoh - Kel'Thuzad"] = {
			["GraphWindowY"] = 0,
			["MainWindow"] = {
				["Position"] = {
					["w"] = 140.000019421976,
					["h"] = 200.0000027354896,
				},
			},
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
				},
			},
			["DetailWindowY"] = 0,
			["GraphWindowX"] = 0,
			["CurDataSet"] = "OverallData",
			["MainWindowVis"] = false,
			["DetailWindowX"] = 0,
		},
		["Neilyoirl - Tichondrius"] = {
			["GraphWindowY"] = 0,
			["MainWindow"] = {
				["AutoHide"] = true,
				["Position"] = {
					["y"] = -335.1117635557699,
					["x"] = 732.4469163544048,
					["w"] = 243.111055884616,
					["h"] = 292.4445993947319,
				},
			},
			["DetailWindowX"] = 0,
			["MainWindowHeight"] = 292.4446169018652,
			["RealtimeWindows"] = {
				["Realtime_!RAID_DAMAGE"] = {
					"!RAID", -- [1]
					"DAMAGE", -- [2]
					"Raid DPS", -- [3]
					0, -- [4]
					3.501426657039244e-005, -- [5]
					200.0000027354896, -- [6]
					232.0000136774479, -- [7]
					false, -- [8]
				},
			},
			["CurDataSet"] = "OverallData",
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
					["Total Bar"] = {
						["a"] = 1,
					},
				},
			},
			["DetailWindowY"] = 0,
			["GraphWindowX"] = 0,
			["HideCollect"] = true,
			["MainWindowWidth"] = 243.1109683489495,
			["Filters"] = {
				["Show"] = {
					["Pet"] = true,
				},
			},
		},
		["Neilyoingame - Kel'Thuzad"] = {
			["GraphWindowY"] = 0,
			["MainWindow"] = {
				["Position"] = {
					["w"] = 140.000019421976,
					["h"] = 200.0000027354896,
				},
			},
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
				},
			},
			["DetailWindowY"] = 0,
			["DetailWindowX"] = 0,
			["MainWindowVis"] = false,
			["GraphWindowX"] = 0,
			["CurDataSet"] = "OverallData",
		},
	},
}
