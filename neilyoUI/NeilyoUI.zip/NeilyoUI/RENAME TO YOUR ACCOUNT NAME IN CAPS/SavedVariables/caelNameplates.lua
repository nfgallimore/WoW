
caelNameplatesDB = {
}
