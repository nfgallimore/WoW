
Hix_QuietTime_DB = {
	["friends"] = true,
	["guild"] = true,
	["autoReply"] = false,
	["events"] = {
		["CHAT_MSG_SAY"] = false,
		["CHAT_MSG_WHISPER"] = true,
		["CHAT_MSG_YELL"] = false,
	},
	["channelInvites"] = true,
	["partyInvites"] = true,
	["alwaysOn"] = false,
}
