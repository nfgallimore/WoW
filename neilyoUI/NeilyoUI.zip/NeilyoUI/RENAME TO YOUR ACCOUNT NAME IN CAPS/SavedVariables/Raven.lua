
RavenDB = {
	["profileKeys"] = {
		["Neilyoirl - Tichondrius"] = "Neilyoirl - Tichondrius",
	},
	["global"] = {
		["BuffDurations"] = {
			["Wound Poison"] = 3261,
			["Crippling Poison"] = 3265,
		},
		["Version"] = "4",
	},
	["profiles"] = {
		["Neilyoirl - Tichondrius"] = {
		},
	},
}
