
SafeQueueDB = {
	["enabled"] = true,
	["announce"] = "self",
	["minimap"] = "on",
}
