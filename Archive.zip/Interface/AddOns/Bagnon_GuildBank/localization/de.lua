--[[
	Bagnon Guild Bank Localization: German
--]]
 
local L = LibStub('AceLocale-3.0'):NewLocale('Bagnon-GuildBank', 'deDE')
if not L then return end

L.Log1 = 'Transaktions Log'
L.Log3 = 'Reiter Info'